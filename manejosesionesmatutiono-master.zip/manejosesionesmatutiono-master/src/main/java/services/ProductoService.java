package services;

import models.Productos;

import java.util.List;

public interface ProductoService {
    List<Productos> listar();
}
