package services;

import models.Productos;

import java.util.Arrays;
import java.util.List;

public class ProductoServiceImplement implements ProductoService {
    @Override
    public List<Productos> listar() {
        return Arrays.asList(
                new Productos(1, "Laptop", "tecnología", 523.25),
                new Productos(2, "Cocina", "hogar", 325.24),
                new Productos(3, "Mouse", "tecnología", 15.25),
                new Productos(4, "Silla", "muebles", 75.00),
                new Productos(5, "Mesa", "muebles", 150.00),
                new Productos(6, "Teléfono", "tecnología", 299.99),
                new Productos(7, "Cafetera", "hogar", 45.50),
                new Productos(8, "Televisor", "tecnología", 450.00),
                new Productos(9, "Auriculares", "tecnología", 30.00),
                new Productos(10, "Estufa", "hogar", 120.00)
        );
    }
}