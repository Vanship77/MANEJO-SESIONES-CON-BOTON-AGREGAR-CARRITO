package controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import models.Carrito;
import models.Productos;
import services.ProductoService;
import services.ProductoServiceImplement;

import java.io.IOException;
import java.util.List;

@WebServlet("/agregarAlCarrito")
public class AgregarAlCarritoServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        int idProducto = Integer.parseInt(req.getParameter("idProducto"));
        ProductoService servicios = new ProductoServiceImplement();
        List<Productos> productos = servicios.listar();

        Productos producto = productos.stream()
                .filter(p -> p.getIdProducto() == idProducto)
                .findFirst()
                .orElse(null);

        if (producto != null) {
            HttpSession session = req.getSession();
            Carrito carrito = (Carrito) session.getAttribute("carrito");
            carrito.agregarProducto(producto);
        }

        resp.sendRedirect(req.getContextPath() + "/productos");
    }
}