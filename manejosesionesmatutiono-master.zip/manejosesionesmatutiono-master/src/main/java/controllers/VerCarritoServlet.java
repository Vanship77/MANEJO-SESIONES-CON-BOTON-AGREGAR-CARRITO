package controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import models.Carrito;
import models.Productos;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/verCarrito")
public class VerCarritoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Carrito carrito = (Carrito) session.getAttribute("carrito");

        resp.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = resp.getWriter()) {
            out.print("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<meta charset=\"utf-8\">");
            out.println("<title>Carrito de Compras</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; background-color: #f8f9fa; }");
            out.println("h1 { color: #343a40; }");
            out.println("table { width: 100%; border-collapse: collapse; margin-top: 20px; }");
            out.println("th, td { padding: 10px; text-align: left; border: 1px solid #dee2e6; }");
            out.println("th { background-color: #6f42c1; color: white; }");
            out.println("tr:nth-child(even) { background-color: #f2f2f2; }");
            out.println("tr:hover { background-color: #e9ecef; }");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Productos en el Carrito</h1>");
            if (carrito != null && !carrito.getProductos().isEmpty()) {
                out.println("<table>");
                out.println("<tr>");
                out.println("<th>PRODUCTO-ID</th>");
                out.println("<th>NOMBRE</th>");
                out.println("<th>CATEGORÍA</th>");
                out.println("<th>PRECIO</th>");
                out.println("</tr>");

                for (Productos pr : carrito.getProductos()) {
                    out.println("<tr>");
                    out.println("<td>" + pr.getIdProducto() + "</td>");
                    out.println("<td>" + pr.getNombre() + "</td>");
                    out.println("<td>" + pr.getCategoria() + "</td>");
                    out.println("<td>" + pr.getPrecio() + "</td>");
                    out.println("</tr>");
                }
                out.println("</table>");
                out.println("<p><a href='" + req.getContextPath() + "/checkout'>Continuar con la compra</a></p>");
            } else {
                out.println("<p>No hay productos en el carrito.</p>");
            }
            out.println("<p><a href='" + req.getContextPath() + "/productos'>Volver a Productos</a></p>");
            out.println("</body>");
            out.println("</html>");
        }
    }
}