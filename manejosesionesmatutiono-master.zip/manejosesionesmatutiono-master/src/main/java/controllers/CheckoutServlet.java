package controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import models.Carrito;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/checkout")
public class CheckoutServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession();
        Carrito carrito = (Carrito) session.getAttribute("carrito");

        resp.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = resp.getWriter()) {
            out.print("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<meta charset=\"utf-8\">");
            out.println("<title>Checkout</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; background-color: #f8f9fa; margin: 0; padding: 20px; }");
            out.println("h1 { color: #343a40; }");
            out.println("p { font-size: 16px; color: #495057; }");
            out.println("a { text-decoration: none; color: #007bff; }");
            out.println("a:hover { text-decoration: underline; }");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Proceso de Checkout</h1>");
            if (carrito != null && !carrito.getProductos().isEmpty()) {
                out.println("<p>Gracias por su compra!</p>");
                // Aquí puedes agregar más lógica para procesar el pago o finalizar la compra
                carrito.vaciar(); // Vaciar el carrito después de la compra
            } else {
                out.println("<p>No hay productos en el carrito para procesar.</p>");
            }
            out.println("<p><a href='" + req.getContextPath() + "/productos'>Volver a Productos</a></p>");
            out.println("</body>");
            out.println("</html>");
        }
    }
}