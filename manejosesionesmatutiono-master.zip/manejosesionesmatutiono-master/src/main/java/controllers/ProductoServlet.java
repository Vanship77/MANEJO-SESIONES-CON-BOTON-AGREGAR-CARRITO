package controllers;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import models.Carrito;
import models.Productos;
import services.LoginService;
import services.LoginServiceSessionImplement;
import services.ProductoService;
import services.ProductoServiceImplement;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.Optional;

@WebServlet("/productos")
public class ProductoServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ProductoService servicios = new ProductoServiceImplement();
        List<Productos> productos = servicios.listar();

        LoginService auth = new LoginServiceSessionImplement();
        Optional<String> usernameOptional = auth.getUsername(req);

        HttpSession session = req.getSession();
        Carrito carrito = (Carrito) session.getAttribute("carrito");
        if (carrito == null) {
            carrito = new Carrito();
            session.setAttribute("carrito", carrito);
        }

        resp.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = resp.getWriter()) {
            out.print("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<meta charset=\"utf-8\">");
            out.println("<title>Productos</title>");
            out.println("<style>");
            out.println("body { font-family: Arial, sans-serif; background-color: #f8f9fa; }");
            out.println("h1 { color: #343a40; }");
            out.println("table { width: 100%; border-collapse: collapse; margin-top: 20px; }");
            out.println("th, td { padding: 10px; text-align: left; border: 1px solid #dee2e6; }");
            out.println("th { background-color: #6f42c1; color: white; }");
            out.println("tr:nth-child(even) { background-color: #f2f2f2; }");
            out.println("tr:hover { background-color: #e9ecef; }");
            out.println("input[type='submit'] { background-color: #6f42c1; color: white; border: none; padding: 10px 15px; cursor: pointer; }");
            out.println("input[type='submit']:hover { background-color: #5a32a3; }");
            out.println("</style>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Lista de Productos</h1>");
            if (usernameOptional.isPresent()) {
                out.println("<div style='color:blue;'> Hola " + usernameOptional.get() + " Bienvenido</div>");
            }
            out.println("<table>");
            out.println("<tr>");
            out.println("<th>PRODUCTO-ID</th>");
            out.println("<th>NOMBRE</th>");
            out.println("<th>CATEGORÍA</th>");
            if (usernameOptional.isPresent()) {
                out.println("<th>PRECIO</th>");
                out.println("<th>ACCIONES</th>");
            }
            out.println("</tr>");

            for (Productos pr : productos) {
                out.println("<tr>");
                out.println("<td>" + pr.getIdProducto() + "</td>");
                out.println("<td>" + pr.getNombre() + "</td>");
                out.println("<td>" + pr.getCategoria() + "</td>");

                if (usernameOptional.isPresent()) {
                    out.println("<td>" + pr.getPrecio() + "</td>");
                    out.println("<td><form action='" + req.getContextPath() + "/agregarAlCarrito' method='post'>");
                    out.println("<input type='hidden' name='idProducto' value='" + pr.getIdProducto() + "'/>");
                    out.println("<input type='submit' value='Agregar al Carrito'/>");
                    out.println("</form></td>");
                } else {
                    out.println("<td colspan='2'>Inicia sesión para ver precios y agregar productos al carrito.</td>");
                }

                out.println("</tr>");
            }
            out.println("</table>");
            out.println("<p><a href='" + req.getContextPath() + "/verCarrito'>Ver Carrito</a></ p>");
            out.println("</body>");
            out.println("</html>");
        }
    }
}