package models;

import java.util.ArrayList;
import java.util.List;

public class Carrito {
    private List<Productos> productos;

    public Carrito() {
        this.productos = new ArrayList<>();
    }

    public void agregarProducto(Productos producto) {
        productos.add(producto);
    }

    public List<Productos> getProductos() {
        return productos;
    }

    public void vaciar() {
        productos.clear();
    }
}